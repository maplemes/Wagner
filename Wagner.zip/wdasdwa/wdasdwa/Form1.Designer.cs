﻿namespace wdasdwa
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtEntradaDados = new System.Windows.Forms.TextBox();
            txtId = new System.Windows.Forms.TextBox();
            txtNome = new System.Windows.Forms.TextBox();
            txtPeso = new System.Windows.Forms.TextBox();
            listBox1 = new System.Windows.Forms.ListBox();
            txtAltura = new System.Windows.Forms.TextBox();
            lblIMC = new System.Windows.Forms.Label();
            lblClassificacao = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            button2 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button5 = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // txtEntradaDados
            // 
            txtEntradaDados.Location = new System.Drawing.Point(385, 40);
            txtEntradaDados.Multiline = true;
            txtEntradaDados.Name = "txtEntradaDados";
            txtEntradaDados.Size = new System.Drawing.Size(241, 109);
            txtEntradaDados.TabIndex = 0;
            // 
            // txtId
            // 
            txtId.Location = new System.Drawing.Point(3, 181);
            txtId.Name = "txtId";
            txtId.Size = new System.Drawing.Size(156, 23);
            txtId.TabIndex = 1;
            txtId.Text = "ID";
            // 
            // txtNome
            // 
            txtNome.Location = new System.Drawing.Point(3, 210);
            txtNome.Name = "txtNome";
            txtNome.Size = new System.Drawing.Size(156, 23);
            txtNome.TabIndex = 2;
            txtNome.Text = "NOME";
            // 
            // txtPeso
            // 
            txtPeso.Location = new System.Drawing.Point(3, 239);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new System.Drawing.Size(156, 23);
            txtPeso.TabIndex = 3;
            txtPeso.Text = "PESO";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new System.Drawing.Point(668, 22);
            listBox1.Name = "listBox1";
            listBox1.Size = new System.Drawing.Size(120, 214);
            listBox1.TabIndex = 4;
            // 
            // txtAltura
            // 
            txtAltura.Location = new System.Drawing.Point(3, 268);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new System.Drawing.Size(156, 23);
            txtAltura.TabIndex = 5;
            txtAltura.Text = "ALTURA";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            lblIMC.Location = new System.Drawing.Point(106, 54);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new System.Drawing.Size(32, 15);
            lblIMC.TabIndex = 6;
            lblIMC.Text = "IMC:";
            // 
            // lblClassificacao
            // 
            lblClassificacao.AutoSize = true;
            lblClassificacao.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            lblClassificacao.Location = new System.Drawing.Point(106, 8);
            lblClassificacao.Name = "lblClassificacao";
            lblClassificacao.Size = new System.Drawing.Size(78, 15);
            lblClassificacao.TabIndex = 7;
            lblClassificacao.Text = "Classificação:";
            // 
            // button1
            // 
            button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button1.Location = new System.Drawing.Point(385, 152);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(131, 23);
            button1.TabIndex = 8;
            button1.Text = "(1)cadastrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button2.Location = new System.Drawing.Point(3, 329);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(156, 22);
            button2.TabIndex = 9;
            button2.Text = "(2)carregar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button3.Location = new System.Drawing.Point(3, 357);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(156, 23);
            button3.TabIndex = 10;
            button3.Text = "(3)atualizar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button4.Location = new System.Drawing.Point(3, 386);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(156, 23);
            button4.TabIndex = 11;
            button4.Text = "(4)excluir";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button5.Location = new System.Drawing.Point(668, 242);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(120, 23);
            button5.TabIndex = 12;
            button5.Text = "(5)gerar html";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.SystemColors.Highlight;
            label1.Location = new System.Drawing.Point(522, 152);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(104, 52);
            label1.TabIndex = 13;
            label1.Text = "ID do Paciente (1º):\r\nNome (2º):\r\nPeso (3º):\r\nAltura (4º):";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = System.Drawing.SystemColors.Highlight;
            label2.Location = new System.Drawing.Point(3, 9);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(97, 60);
            label2.TabIndex = 14;
            label2.Text = "CLASSIFICAÇÃO:\r\n\r\n\r\nIMC:";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = System.Drawing.SystemColors.Highlight;
            label3.Location = new System.Drawing.Point(660, 4);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(128, 15);
            label3.TabIndex = 15;
            label3.Text = "Pacientes Cadastrados:";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = System.Drawing.SystemColors.Highlight;
            label4.Location = new System.Drawing.Point(440, 22);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(123, 15);
            label4.TabIndex = 16;
            label4.Text = "Cadastro de Pacientes";
            label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = System.Drawing.SystemColors.Highlight;
            label5.Location = new System.Drawing.Point(39, 163);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(76, 15);
            label5.TabIndex = 17;
            label5.Text = "Informações:";
            label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = System.Drawing.SystemColors.Highlight;
            label6.Location = new System.Drawing.Point(58, 311);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(42, 15);
            label6.TabIndex = 18;
            label6.Text = "Ações:";
            label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.AppWorkspace;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblClassificacao);
            Controls.Add(lblIMC);
            Controls.Add(txtAltura);
            Controls.Add(listBox1);
            Controls.Add(txtPeso);
            Controls.Add(txtNome);
            Controls.Add(txtId);
            Controls.Add(txtEntradaDados);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtEntradaDados;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label lblIMC;
        private System.Windows.Forms.Label lblClassificacao;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}
