﻿ /* *******************************************************************
 * Colegio Técnico Antônio Teixeira Fernandes (Univap)
 * Curso Técnico em Informática - Data de Entrega: 08/11/2024
 * Autores do Projeto: MARCO AURÉLIO PIMENTA LEMES
 *                     DAVI OLIVEIRA MATTOS
 * Turma: 2IID
 * Atividade Proposta em aula
 * Observação: 
 * 
 * Form1.cs
 * ************************************************************/     

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using System.Xml;

namespace wdasdwa
{
    public partial class Form1 : Form
    {
        private GerenciadorPacientes gerenciador = new GerenciadorPacientes();

        public class Paciente
        {
            public int Id { get; set; }
            public string Nome { get; set; }
            public double Peso { get; set; } // Em Kg
            public double Altura { get; set; } // Em metros
            public double IMC => Math.Round(Peso / (Altura * Altura), 2);
            public string Classificacao
            {
                get
                {
                    if (IMC < 18.5) return "Magreza";
                    else if (IMC < 25) return "Saudável";
                    else if (IMC < 30) return "Sobrepeso";
                    else if (IMC < 35) return "Obesidade Grau I";
                    else if (IMC < 40) return "Obesidade Grau II";
                    else return "Obesidade Grau III";
                }
            }
        }

        public class GerenciadorPacientes
        {
            private const string FilePath = "pacientes.json";

            public List<Paciente> CarregarPacientes()
            {
                if (!File.Exists(FilePath)) return new List<Paciente>();
                var json = File.ReadAllText(FilePath);
                return JsonConvert.DeserializeObject<List<Paciente>>(json) ?? new List<Paciente>();
            }

            public void SalvarPacientes(List<Paciente> pacientes)
            {
                var json = JsonConvert.SerializeObject(pacientes, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(FilePath, json);
            }

            public void AlterarPaciente(int id, string novoNome, double novoPeso, double novaAltura)
            {
                var pacientes = CarregarPacientes();
                var paciente = pacientes.FirstOrDefault(p => p.Id == id);

                if (paciente != null)
                {
                    paciente.Nome = novoNome;
                    paciente.Peso = novoPeso;
                    paciente.Altura = novaAltura;
                    SalvarPacientes(pacientes);
                }
                else
                {
                    throw new Exception("Paciente não encontrado.");
                }
            }

            public void ExcluirPaciente(int id)
            {
                var pacientes = CarregarPacientes();
                var pacienteParaExcluir = pacientes.FirstOrDefault(p => p.Id == id);

                if (pacienteParaExcluir != null)
                {
                    pacientes.Remove(pacienteParaExcluir);
                    SalvarPacientes(pacientes);
                }
                else
                {
                    throw new Exception("Paciente não encontrado.");
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void AtualizarListaPacientes()
        {
            listBox1.Items.Clear();
            var pacientes = gerenciador.CarregarPacientes();
            foreach (var paciente in pacientes)
            {
                listBox1.Items.Add($"{paciente.Id}: {paciente.Nome} - IMC: {paciente.IMC} - {paciente.Classificacao}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] linhas = txtEntradaDados.Lines;

            if (linhas.Length < 4)
            {
                MessageBox.Show("Por favor, insira todos os campos necessários:\nId, Nome, Peso e Altura em linhas separadas.");
                return;
            }

            try
            {
                int id = int.Parse(linhas[0]);
                string nome = linhas[1];
                double peso = double.Parse(linhas[2]);
                double altura = double.Parse(linhas[3]);

                var novoPaciente = new Paciente
                {
                    Id = id,
                    Nome = nome,
                    Peso = peso,
                    Altura = altura
                };

                var pacientes = gerenciador.CarregarPacientes();
                if (pacientes.Exists(p => p.Id == id))
                {
                    MessageBox.Show("Paciente com esse ID já cadastrado.");
                    return;
                }

                pacientes.Add(novoPaciente);
                gerenciador.SalvarPacientes(pacientes);
                AtualizarListaPacientes();

                MessageBox.Show("Paciente cadastrado com sucesso!");
            }
            catch (FormatException)
            {
                MessageBox.Show("Formato inválido. Certifique-se de que o Id é um número inteiro e o Peso e Altura são números decimais.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var pacientes = gerenciador.CarregarPacientes();
            if (!int.TryParse(txtId.Text, out int id))
            {
                MessageBox.Show("Por favor, insira um ID válido.");
                return;
            }

            var paciente = pacientes.Find(p => p.Id == id);

            if (paciente != null)
            {
                txtNome.Text = paciente.Nome;
                txtPeso.Text = paciente.Peso.ToString();
                txtAltura.Text = paciente.Altura.ToString();
                lblIMC.Text = paciente.IMC.ToString();
                lblClassificacao.Text = paciente.Classificacao;
            }
            else
            {
                MessageBox.Show("Paciente não encontrado.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var pacientes = gerenciador.CarregarPacientes();

            string htmlContent = "<!DOCTYPE html><html><head><meta charset='UTF-8'>" +
                "<title>Relatório de IMC</title><script src='https://cdn.plot.ly/plotly-2.27.0.min.js'></script>" +
                "</head><body><center><h2>Relatório de Índice de Massa Corporal</h2>" +
                "<div id='myDiv' style='width:500px;height:500px;'></div></center><script>" +
                "var data = [{type: 'scatterpolar', r: [" +
                string.Join(",", pacientes.ConvertAll(p => p.IMC.ToString())) +
                "], theta: ['Magreza','Saudável','Sobrepeso', 'OBG-I', 'OBG-II', 'OBG-III'], fill: 'toself'}];" +
                "var layout = {polar: {radialaxis: {visible: true, range: [0, 50]}}, showlegend: false};" +
                "Plotly.newPlot('myDiv', data, layout);</script></body></html>";

            File.WriteAllText("RelatorioIMC.html", htmlContent);
            MessageBox.Show("Relatório HTML gerado com sucesso!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out int id))
            {
                MessageBox.Show("Por favor, insira um ID válido.");
                return;
            }

            if (!double.TryParse(txtPeso.Text, out double novoPeso) || !double.TryParse(txtAltura.Text, out double novaAltura))
            {
                MessageBox.Show("Por favor, insira valores numéricos válidos para Peso e Altura.");
                return;
            }

            string novoNome = txtNome.Text;

            try
            {
                gerenciador.AlterarPaciente(id, novoNome, novoPeso, novaAltura);
                MessageBox.Show("Paciente alterado com sucesso!");
                AtualizarListaPacientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao alterar o paciente: {ex.Message}");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out int id))
            {
                MessageBox.Show("Por favor, insira um ID válido.");
                return;
            }

            try
            {
                gerenciador.ExcluirPaciente(id);
                MessageBox.Show("Paciente excluído com sucesso!");
                AtualizarListaPacientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir o paciente: {ex.Message}");
            }
        }
    }
}